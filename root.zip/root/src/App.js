import React from "react";
import QrCodeCard from "./components/QrCodeCard";


function App() {
  

  return (
    
    <div className="App">
        <QrCodeCard />
    </div>

    
    
  );
}

export default App;
